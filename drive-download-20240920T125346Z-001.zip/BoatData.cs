using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class BoatData : MonoBehaviour
{
    private Transform boatTransform;
    private Rigidbody boatRigidbody;

    private string filePath = "/home/marus_user/marus-example/Assets/marus-core/Scripts/Boatdata.txt";
    private bool isRecording = false;

    // Start is called before the first frame update
    void Start()
    {
        // Get references to the Transform and Rigidbody components
        boatTransform = GetComponent<Transform>();
        boatRigidbody = GetComponent<Rigidbody>();

        // Check if the file path is correct and writable
        Debug.Log("Attempting to write to: " + filePath);
        try
        {
            File.WriteAllText(filePath, "Test Entry: This should create the file and write this text.\n");
            Debug.Log("File successfully written.");
        }
        catch (IOException ex)
        {
            Debug.LogError("Failed to write file: " + ex.Message);
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Check if the boat is moving
        if (boatRigidbody.velocity.magnitude > 1.0f && !isRecording)
        {
            // Start recording when the boat starts moving
            StartRecording();
        }
    }

    void StartRecording()
    {
        // Set the recording flag to true
        isRecording = true;

        try
        {
            // Create or clear the existing file
            File.WriteAllText(filePath, "Time (s)\tPosition (x, y, z)\tOrientation (x, y, z, w)\tVelocity (x, y, z)\tSpeed (units/s)\tDirection (degrees)\n");
            Debug.Log("File initialized for recording data.");
        }
        catch (IOException ex)
        {
            Debug.LogError("Failed to initialize file for recording: " + ex.Message);
        }

        // Start recording data every 0.1 seconds
        InvokeRepeating("RecordData", 0f, 0.1f);
    }

    void RecordData()
    {
        // Get current time
        float currentTime = Time.time;
        // Get position, orientation, velocity, and speed
        Vector3 position = boatTransform.position;
        Quaternion orientation = boatTransform.rotation;
        Vector3 velocity = boatRigidbody.velocity;
        float speed = velocity.magnitude;

        // Calculate the direction (heading) of the boat
        float direction = Mathf.Atan2(velocity.x, velocity.z) * Mathf.Rad2Deg;

        // Ensure direction is within [0, 360] degrees
        direction = (direction + 360) % 360;

        // Log the time, position, orientation, velocity, speed, and direction to a file
        string logEntry = $"{currentTime}\t{position.x}, {position.y}, {position.z}\t{orientation.x}, {orientation.y}, {orientation.z}, {orientation.w}\t{velocity.x}, {velocity.y}, {velocity.z}\t{speed}\t{direction}\n";

        try
        {
            File.AppendAllText(filePath, logEntry);
            Debug.Log($"Data recorded at {currentTime}: Position - {position}, Speed - {speed}, Direction - {direction}");
        }
        catch (IOException ex)
        {
            Debug.LogError("Failed to append data to file: " + ex.Message);
        }
    }
}

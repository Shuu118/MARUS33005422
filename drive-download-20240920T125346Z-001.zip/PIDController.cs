using System;
using UnityEngine;

[Serializable]
public class PIDController
{
    public float proportionalGain = 1.0f;  // Kp
    public float integralGain = 0.1f;      // Ki
    public float derivativeGain = 0.01f;   // Kd

    public float outputMin = -1.0f;        // Minimum output value
    public float outputMax = 1.0f;         // Maximum output value
    public float integralSaturation = 10.0f; // Limit for the integral term

    private float previousError;
    private float integral;

    public PIDController(float kp, float ki, float kd)
    {
        proportionalGain = kp;
        integralGain = ki;
        derivativeGain = kd;
    }

    public void Reset()
    {
        previousError = 0f;
        integral = 0f;
    }

    public float Update(float currentError, float deltaTime)
    {
        // Calculate the integral term with saturation
        integral += currentError * deltaTime;
        integral = Mathf.Clamp(integral, -integralSaturation, integralSaturation);

        // Calculate the derivative term
        float derivative = (currentError - previousError) / deltaTime;

        // Calculate the proportional term
        float proportional = proportionalGain * currentError;

        // Calculate the integral term
        float integralValue = integralGain * integral;

        // Calculate the derivative term
        float derivativeValue = derivativeGain * derivative;

        // Calculate the PID output
        float output = proportional + integralValue + derivativeValue;

        // Clamp the output to the specified minimum and maximum values
        output = Mathf.Clamp(output, outputMin, outputMax);

        // Save the current error for the next frame
        previousError = currentError;

        // Return the computed output
        return output;
    }

    public float UpdateAngle(float currentAngle, float targetAngle, float deltaTime)
    {
        float error = Mathf.DeltaAngle(currentAngle, targetAngle);
        return Update(error, deltaTime);
    }
}


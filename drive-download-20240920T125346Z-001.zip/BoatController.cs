using UnityEngine;

public class BoatController : MonoBehaviour
{
    public Transform boatTransform;
    public Rigidbody boatRigidbody;
    public PIDController pidController = new PIDController(1.0f, 0.0f, 0.0f);  // Initialized PID gains (adjust as needed)

    public float boatSpeed = 1.0f;    // Boat speed multiplier
    public float outputMin = -1.0f;   // Minimum PID output
    public float outputMax = 1.0f;    // Maximum PID output
    public float targetZ = 100.0f;    // Target position along the Z-axis

    void Start()
    {
        if (boatRigidbody == null)
        {
            Debug.LogError("Boat Rigidbody is not assigned.");
        }

        // Set the clamping values for the PID controller
        pidController.OutputMin = outputMin;
        pidController.OutputMax = outputMax;
    }

    void Update()
    {
        if (boatRigidbody == null || boatTransform == null)
        {
            Debug.LogError("Boat Rigidbody or Transform is not assigned.");
            return;
        }

        // Calculate the error (difference between target position and current position)
        float error = CalculateError();

        // Get the PID controller's output based on the error and time since last frame
        float pidOutput = pidController.Update(error, Time.deltaTime);

        // Log the error and PID output for debugging
        Debug.Log($"Error: {error}, PID Output: {pidOutput}");

        // Apply the PID output as force to the boat's Rigidbody
        boatRigidbody.AddForce(boatTransform.forward * pidOutput * boatSpeed, ForceMode.Force);

        // Log the boat position and applied force for debugging
        Debug.Log($"Boat Position: {boatTransform.position}, PID Output (z-axis): {pidOutput}");
    }

    float CalculateError()
    {
        // Calculate the error as the difference between the target position and the current position on the Z-axis
        return targetZ - boatTransform.position.z;
    }
}

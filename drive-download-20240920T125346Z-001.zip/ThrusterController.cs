using System.Collections.Generic;
using MathNet.Numerics.LinearAlgebra;
using UnityEngine;
using Marus.Actuators;

namespace Marus.Actuators
{
    public class ThrusterController : MonoBehaviour
    {
        public List<Thruster> thrusters = new List<Thruster>();

        // Applies direct input values to each thruster
        public void ApplyInput(float[] array)
        {
            for (int i = 0; i < thrusters.Count; i++)
            {
                if (i < array.Length)
                {
                    thrusters[i].ApplyInput(array[i]);
                }
                else
                {
                    break;
                }
            }
        }

        // Applies forces calculated from a tau vector and an inverse allocation matrix
        public void ApplyInput(Vector3 tau, Matrix<double> inverseAllocationMatrix)
        {
            var vec = CreateVector.Dense<double>(3);
            vec[0] = tau.x;
            vec[1] = tau.y;
            vec[2] = tau.z;

            var forces = inverseAllocationMatrix.Multiply(vec);

            for (int i = 0; i < thrusters.Count; i++)
            {
                if (i < forces.Count)
                {
                    var inputValue = thrusters[i].GetInputFromForce((float)forces[i]);
                    thrusters[i].ApplyInput(inputValue);
                }
                else
                {
                    break;
                }
            }
        }

        // New method: Applies the output from a PID controller to the thrusters
        public void ApplyPIDOutput(float[] pidOutput)
        {
            for (int i = 0; i < thrusters.Count; i++)
            {
                if (i < pidOutput.Length)
                {
                    thrusters[i].ApplyInput(pidOutput[i]);
                }
                else
                {
                    break;
                }
            }
        }
    }
}
